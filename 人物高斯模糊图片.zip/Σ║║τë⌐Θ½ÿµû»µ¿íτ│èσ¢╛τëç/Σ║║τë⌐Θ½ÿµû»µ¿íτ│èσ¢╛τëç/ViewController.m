//
//  ViewController.m
//  人物高斯模糊图片
//
//  Created by Sven on 17/3/7.
//  Copyright © 2017年 Sven. All rights reserved.
//


//*** 很多时候，根据项目需求，在个人信息页面上需要用用户的头像虚化来做背景，提升页面的个人主义感。本来找了个很多方法，一一尝试过，这个应该是性能最好的，分享给大家 自己也顺便做个标记，以备不时之需！


#import "ViewController.h"
#import "UIImage+ImageEffects.h"
/*
 屏幕宽度
 **/
#define KPZ_WIDTH ([UIScreen mainScreen].bounds.size.width)
/*
 屏幕高度
 **/
#define KPZ_HEIGHT ([UIScreen mainScreen].bounds.size.height)

@interface ViewController ()

// 原始照片
@property(nonatomic,strong)UIImageView * orgImgView ;
// 高斯转换后的照片
@property(nonatomic,strong)UIImageView * convertImgView;


@end

@implementation ViewController

- (UIImageView *)orgImgView
{
   if(!_orgImgView)
   {
       _orgImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"neo.jpg"]];
       _orgImgView.frame = CGRectMake(KPZ_WIDTH/2-100, KPZ_HEIGHT/2-100, 100, 100);
   }
    return _orgImgView;

}

- (UIImageView *)convertImgView
{
    if (!_convertImgView) {
        _convertImgView = [[UIImageView alloc]initWithImage:[self.orgImgView.image blurImageWithRadius:4]];
        _convertImgView.frame = self.view.bounds;
    }
    return _convertImgView;

}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.convertImgView];
    
    [self.view addSubview:self.orgImgView];
    
   
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
